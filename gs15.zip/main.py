import os
from contexte import chemin_coffre_fort, chemin_Utilisateurs, chemin_doc_crypté, chemin_historique, chemin_bd_json
from contexte import contexte
import authentification
# import gestion_fichier
import utilitaire
import dérivation
import gestion_fichier
import json
import cobra   #
from datetime import datetime, timedelta
from utilitaire import generer_cle_RSA, renouveler_cle_RSA
from journalisation import journaliser_action


def initialiser_repertoires():
    os.makedirs(chemin_coffre_fort, exist_ok=True)
    os.makedirs(chemin_Utilisateurs, exist_ok=True)
    os.makedirs(chemin_doc_crypté, exist_ok=True)
    os.makedirs(chemin_historique, exist_ok=True)


    # Génération des clés RSA pour le coffre-fort si elles n'existent pas
    chemin_cle_coffre = os.path.join(chemin_coffre_fort, "cles_coffre.json")
    if not os.path.exists(chemin_cle_coffre):
        cle_privee, cle_publique, expiration, p = generer_cle_RSA()
        sauvegarder_cles(chemin_cle_coffre, cle_privee, cle_publique, expiration)
        print("Clés RSA pour le coffre-fort générées et sauvegardées.")
    else:
        verifier_cle_perimee(chemin_cle_coffre)

    print("Arborescence des répertoires initialisée.")



def sauvegarder_cles(chemin, cle_privee, cle_publique, expiration):
    with open(chemin, "w") as fichier:
        json.dump({
            "cle_privee":  list(cle_privee),
            "cle_publique": list(cle_publique),
            "expiration": expiration.isoformat()
        }, fichier)
        
def verifier_cle_perimee(chemin):
    with open(chemin, "r") as fichier:
        cles = json.load(fichier)
        expiration = datetime.fromisoformat(cles["expiration"])
        if expiration < datetime.utcnow():
            print("Les clés RSA du coffre-fort sont expirées. Renouvellement en cours...")
            cle_privee, cle_publique, nouvelle_expiration = renouveler_cle_RSA()
            sauvegarder_cles(chemin, cle_privee, cle_publique, nouvelle_expiration)
            #enregistrer_renouvellement_utilisateur(nom_utilisateur)
            print("Clés RSA du coffre-fort renouvelées avec succès.")
        else:
            print("Les clés RSA du coffre-fort sont encore valides.")

def utilisateur_existe(nom_utilisateur):
    if os.path.exists(chemin_bd_json):
        with open(chemin_bd_json, 'r') as f:
            utilisateurs = json.load(f)
            return nom_utilisateur in utilisateurs
    return False

def creer_arborescence_utilisateur(utilisateur):
    chemin_utilisateur = os.path.join(chemin_Utilisateurs, utilisateur)
    os.makedirs(chemin_utilisateur, exist_ok=True)
    os.makedirs(os.path.join(chemin_utilisateur, "cles"), exist_ok=True)
    os.makedirs(os.path.join(chemin_utilisateur, "fichiers_cryptes"), exist_ok=True)
    os.makedirs(os.path.join(chemin_utilisateur, "journaux"), exist_ok=True)


def menu_principal():
    print("Bienvenue dans le coffre-fort numérique!")
    while True:
        print("1. Inscription")
        print("2. Connexion")
        print("3. Quitter")
        choix = input("Votre choix: ")

        if choix == "1":
            contexte.nom_utilisateur = input("Entrez un nom d'utilisateur: ")
            while utilisateur_existe(contexte.nom_utilisateur):
                contexte.nom_utilisateur = input("Le nom que vous avez choisi existe déjà. Veuillez saisir un autre nom ou connectez-vous au compte existant: ")
            mot_de_passe = input("Entrez un mot de passe: ")
            while not utilitaire.verifier_mot_de_passe(mot_de_passe):
                mot_de_passe = input("Le mot de passe n'est pas robuste. Veuillez recommencer: ")
            sel = utilitaire.generer_sel()
            contexte.cle_derivee = dérivation.derivee_cle(mot_de_passe, sel, iterations = 1000, longueur_cle = 16)
            #
            print(contexte.cle_derivee)
            print("taille cle derivee",cobra.count_bits(cobra.text_to_binary(contexte.cle_derivee)))
            print(cobra.text_to_binary(contexte.cle_derivee))
            #
            cle_privee, cle_publique, expiration, p = generer_cle_RSA()
            creer_arborescence_utilisateur(contexte.nom_utilisateur)
            utilitaire.ajouter_utilisateur(contexte.nom_utilisateur, sel, contexte.cle_derivee, cle_privee, cle_publique, expiration, p)
            journaliser_action("Inscription", contexte.nom_utilisateur, "Nouvel utilisateur inscrit", "vous vous êtes inscrit.")
            print("Inscription réussie!")
        elif choix == "2":
            contexte.nom_utilisateur = input("Nom d'utilisateur: ")
            if authentification.authentification_double_sens(contexte.nom_utilisateur) is None:
                journaliser_action("Connexion", contexte.nom_utilisateur, "un nouvel utilisateur conecté", "vous vous êtes connecté.")
                  #ne supprime pas mes choses ok  b
                gestion_fichier.menu_general(contexte.nom_utilisateur)
            else:
                print("Échec de la connexion.")
        elif choix == "3":
            print("À bientôt!")
            break
        else:
            print("Choix invalide.")

if __name__ == "__main__":
    initialiser_repertoires()  
    menu_principal() 

